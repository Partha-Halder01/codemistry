<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PageView;
use Carbon\Carbon;

class AdminAnalyticsController extends Controller
{
    public function getDashboardData(Request $request)
    {
        $startDate = $request->query('start_date') ? Carbon::parse($request->query('start_date'))->startOfDay() : Carbon::now()->subDays(30)->startOfDay();
        $endDate = $request->query('end_date') ? Carbon::parse($request->query('end_date'))->endOfDay() : Carbon::now()->endOfDay();

        $query = PageView::whereBetween('created_at', [$startDate, $endDate]);

        // Total Visitors (unique sessions)
        $totalVisitors = (clone $query)->distinct('session_id')->count('session_id');

        // Total Page Views
        $totalPageViews = (clone $query)->count();

        // Average Time on Site
        $totalTimeSpent = (clone $query)->sum('time_spent');
        $averageTime = $totalVisitors > 0 ? floor($totalTimeSpent / $totalVisitors) : 0;

        // Peak Live Users (Sessions active in the last 5 minutes from NOW)
        $liveUsers = PageView::where('last_ping_at', '>=', Carbon::now()->subMinutes(5))
            ->distinct('session_id')
            ->count('session_id');

        // Top Pages
        // Group by path, count views, average time spent
        $topPages = (clone $query)
            ->select('path', \DB::raw('count(*) as views'), \DB::raw('FLOOR(AVG(time_spent)) as avg_time'))
            ->groupBy('path')
            ->orderByDesc('views')
            ->limit(10)
            ->get();

        // Top Services Viewed
        $topServices = (clone $query)
            ->whereNotNull('service_id')
            ->with('service:id,name') // Ensure we define this relation
            ->select('service_id', \DB::raw('count(*) as views'))
            ->groupBy('service_id')
            ->orderByDesc('views')
            ->limit(10)
            ->get()
            ->map(function ($item) {
                return [
                    'name' => $item->service ? $item->service->name : 'Unknown Service',
                    'views' => $item->views
                ];
            });

        // Top Locations (Countries)
        $topCountries = (clone $query)
            ->whereNotNull('country')
            ->select('country', \DB::raw('count(DISTINCT session_id) as visitors'))
            ->groupBy('country')
            ->orderByDesc('visitors')
            ->limit(5)
            ->get();

        // Top Locations (Cities)
        $topCities = (clone $query)
            ->whereNotNull('city')
            ->select('city', 'country', \DB::raw('count(DISTINCT session_id) as visitors'))
            ->groupBy('city', 'country')
            ->orderByDesc('visitors')
            ->limit(5)
            ->get();

        return response()->json([
            'summary' => [
                'total_visitors' => $totalVisitors,
                'total_views' => $totalPageViews,
                'average_time' => $this->formatTime($averageTime),
                'live_users' => $liveUsers
            ],
            'top_pages' => $topPages,
            'top_services' => $topServices,
            'top_countries' => $topCountries,
            'top_cities' => $topCities
        ]);
    }

    private function formatTime($seconds)
    {
        $minutes = floor($seconds / 60);
        $remainingSeconds = $seconds % 60;
        return sprintf('%dm %02ds', $minutes, $remainingSeconds);
    }
}
