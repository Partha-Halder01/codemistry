<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PageView;
use Illuminate\Support\Facades\Http;

class AnalyticsController extends Controller
{
    public function track(Request $request)
    {
        $request->validate([
            'session_id' => 'required|string',
            'path' => 'required|string',
            'time_spent' => 'required|integer'
        ]);

        $ip = $request->ip();
        
        // Find existing record for this session and path within the last hour
        $pageView = PageView::where('session_id', $request->session_id)
            ->where('path', $request->path)
            ->where('created_at', '>=', now()->subHour())
            ->first();

        if ($pageView) {
            // Update time spent and last ping
            $pageView->time_spent = max($pageView->time_spent, $request->time_spent);
            $pageView->last_ping_at = now();
            $pageView->save();
        } else {
            // New view
            $geoData = $this->getGeoLocation($ip);
            
            // Try to resolve service ID if path matches /services/{slug}
            $serviceId = null;
            if (preg_match('/^\/services\/([^\/]+)$/', $request->path, $matches)) {
                $service = \App\Models\Service::where('slug', $matches[1])->first();
                if ($service) {
                    $serviceId = $service->id;
                }
            }

            $pageView = PageView::create([
                'session_id' => $request->session_id,
                'ip_address' => $ip,
                'country' => $geoData['country'] ?? null,
                'city' => $geoData['city'] ?? null,
                'path' => $request->path,
                'service_id' => $serviceId,
                'time_spent' => $request->time_spent,
                'last_ping_at' => now(),
            ]);
        }

        return response()->json(['success' => true]);
    }

    private function getGeoLocation($ip)
    {
        // For local development loopback IPs, return null
        if ($ip === '127.0.0.1' || $ip === '::1') return ['country' => 'Localhost', 'city' => 'Local'];

        try {
            $response = Http::timeout(2)->get("http://ip-api.com/json/{$ip}?fields=status,country,city");
            if ($response->successful() && $response->json('status') === 'success') {
                return [
                    'country' => $response->json('country'),
                    'city' => $response->json('city')
                ];
            }
        } catch (\Exception $e) {
            // Silently fail geo-lookup
        }
        return ['country' => 'Unknown', 'city' => 'Unknown'];
    }
}
